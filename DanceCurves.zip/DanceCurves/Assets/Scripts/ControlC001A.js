//#pragma strict
var Dancer:GameObject;
var DancerSet:GameObject;
var Dancers:GameObject[];
var ND:int;
var Phi:float;
var StartCode:String;
var UpdateCode:String;
var n:int;
function Start () 
{
	for(n=0;n<ND;n++)
	{
		Dancers[n]=Instantiate(Dancer);
		Dancers[n].transform.parent=DancerSet.transform;
	}
	
	StartCode=ReadScript("ControlC001AStart.txt");
	UpdateCode=ReadScript("ControlC001AUpdate.txt");

	eval(StartCode);
}
function Update () 
{
	eval(UpdateCode);
}
function LateUpdate () 
{
	Dancer.transform.position.y=-100;
}
function ReadScript(ScriptName:String):String
{
	var ScriptCode:String;
	var fn=Application.dataPath + "/StreamingAssets/"+ScriptName;
	if(System.IO.File.Exists(fn)){var sr0 = new StreamReader(fn);ScriptCode = sr0.ReadToEnd(); sr0.Close();}
	print(ScriptCode);
	return ScriptCode;
}
function cos(phi:float) : float
{
	return Mathf.Cos(phi);
}
function sin(phi:float) : float
{
	return Mathf.Sin(phi);
}
function atan(x:float,y:float) : float
{
	return Mathf.Atan2(x,y);
}
function abs(x:float) : float
{
	return Mathf.Abs(x);
}
function min(x:float,y:float) : float
{
	return Mathf.Min(x,y);
}

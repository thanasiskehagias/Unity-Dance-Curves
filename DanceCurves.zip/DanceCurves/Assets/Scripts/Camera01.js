﻿import System.IO;

var Target : GameObject;
var TIME:int;
var SwTime:int;
var StartName:String;
var StartCode:String;
var UpdateName:String;
var UpdateCode:String;

var H1:float;
var R0:float;
var w1:float;
var w2:float;
var CamState:int;
var SwitchTime:int;

function Start () 
{
	TIME=0;
	StartName="Camera01Start.txt";
	StartCode=ReadScript(StartName);
	UpdateName="Camera01Update.txt";
	UpdateCode=ReadScript(UpdateName);

	eval(StartCode);
}

function Update () 
{
	TIME=TIME+1;
	eval(UpdateCode);
}
function ReadScript(ScriptName:String):String
{
	var ScriptCode:String;
	var fn=Application.dataPath + "/StreamingAssets/"+ScriptName;
	if(System.IO.File.Exists(fn)){var sr0 = new StreamReader(fn);ScriptCode = sr0.ReadToEnd(); sr0.Close();}
	//print(ScriptCode);
	return ScriptCode;
}
function cos(phi:float) : float
{
	return Mathf.Cos(phi);
}
function sin(phi:float) : float
{
	return Mathf.Sin(phi);
}
function atan(x:float,y:float) : float
{
	return Mathf.Atan2(x,y);
}
function abs(x:float) : float
{
	return Mathf.Abs(x);
}
function min(x:float,y:float) : float
{
	return Mathf.Min(x,y);
}

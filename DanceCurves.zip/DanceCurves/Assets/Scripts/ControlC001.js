//#pragma strict
import UnityEngine.UI;
var Music:GameObject;
var MusicScript:MusicPlayer;
var MusicFile:String;
var MusicLength:float;
var Light01:GameObject;
var Light01PointLight:Light;
var Teleport:GameObject;
var Spiral:GameObject;
var DancerA:GameObject;
var DancerSetA:GameObject;
var DancersA:GameObject[];
var NumDancersA:int;
var DancerB:GameObject;
var DancerSetB:GameObject;
var DancersB:GameObject[];
var NumDancersB:int;
var StartCode:String;
var UpdateCode:String;
var Phi:float;
var TIME=0;
var n:int;
var FPS:int;
var ShowFPS:boolean;
function Start () 
{
	for(n=0;n<NumDancersA;n++)
	{
		DancersA[n]=Instantiate(DancerA);
		DancersA[n].transform.parent=DancerSetA.transform;
	}
	for(n=0;n<NumDancersB;n++)
	{
		DancersB[n]=Instantiate(DancerB);
		DancersB[n].transform.parent=DancerSetB.transform;
	}

	StartCode=ReadScript("Control01Start.txt");
	UpdateCode=ReadScript("Control01Update.txt");

	eval(StartCode);
	MusicScript.targetFilename=MusicFile;
}
function Update () 
{
	MusicLength=MusicScript.MusicLength;
	//MusicLength=60;
	eval(UpdateCode);
}
function OnGUI() 
{
	if(ShowFPS)
	{
		FPS=Mathf.Round(1/Time.deltaTime);
		//GUILayout.Label(FPS.ToString());
		GUILayout.Label("<color=white><size=25><b>"+FPS.ToString()+"</b></size></color>");
	}
}
function ReadScript(ScriptName:String):String
{
	var ScriptCode:String;
	var fn=Application.dataPath + "/StreamingAssets/"+ScriptName;
	if(System.IO.File.Exists(fn)){var sr0 = new StreamReader(fn);ScriptCode = sr0.ReadToEnd(); sr0.Close();}
	//print(ScriptCode);
	return ScriptCode;
}
function cos(phi:float) : float
{
	return Mathf.Cos(phi);
}
function sin(phi:float) : float
{
	return Mathf.Sin(phi);
}
function atan(x:float,y:float) : float
{
	return Mathf.Atan2(x,y);
}
function abs(x:float) : float
{
	return Mathf.Abs(x);
}
function min(x:float,y:float) : float
{
	return Mathf.Min(x,y);
}

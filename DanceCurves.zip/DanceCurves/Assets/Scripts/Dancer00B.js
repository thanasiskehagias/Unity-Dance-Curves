var Root:GameObject;
var Hips:GameObject;
var StartCode:String;
var UpdateCode:String;
var LateUpdateCode:String;
var K:float;
var r:float;
var R0:float;
var w:float;
var Phi:float;
var PhiNew:float;
var kr:float;
var x0:float;
var z0:float;
var dx:float;
var dz:float;
var t:float;
function Start () 
{
	StartCode=ReadScript("Dancer00BStart.txt");
	UpdateCode=ReadScript("Dancer00BUpdate.txt");
	LateUpdateCode=ReadScript("Dancer00BLateUpdate.txt");

	eval(StartCode);
}
function Update () 
{
	eval(UpdateCode);
}
function LateUpdate () 
{
	eval(LateUpdateCode);
}
function ReadScript(ScriptName:String):String
{
	var ScriptCode:String;
	var fn=Application.dataPath + "/StreamingAssets/"+ScriptName;
	if(System.IO.File.Exists(fn)){var sr0 = new StreamReader(fn);ScriptCode = sr0.ReadToEnd(); sr0.Close();}
	//print(ScriptCode);
	return ScriptCode;
}
function cos(phi:float) : float
{
	return Mathf.Cos(phi);
}
function sin(phi:float) : float
{
	return Mathf.Sin(phi);
}
function atan(x:float,y:float) : float
{
	return Mathf.Atan2(x,y);
}
